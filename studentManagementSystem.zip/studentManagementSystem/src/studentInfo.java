import java.util.Scanner;

public class studentInfo {

    String gradeLevel;

    String name;

    int balance;

    int costPerCourse = 600;

    String courses = " ";

    String uniqueID = "";

    public studentInfo() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter First & Last Name: ");

         name = scanner.nextLine();

        System.out.println("Enter Grade Level");

        gradeLevel = scanner.nextLine();

        System.out.println(studentID());

        System.out.println(courseOptions());

    }

    public String studentID() {

        uniqueID = gradeLevel;

        int length = gradeLevel.length();

        String numberSet = "1234567890";

        char[] id= new char[5 - length];
        for (int i = 0; i < 5 - length; i++) {
            int random = (int) (Math.random() * numberSet.length());
            id[i] = numberSet.charAt(random);
        }
        uniqueID += String.valueOf(id);
        return "Student ID: " +uniqueID;

    }
 public String courseOptions() {
     Scanner scanner = new Scanner(System.in);

     System.out.println("Select Course Options To Add:\n1 for Film & Media\n2 For English\n3 for Public Relations\n4 for American History\n5 for Psychology\n6  for Student Status\n7 to Pay Balance\n0 to Exit");

     int courseSelect = scanner.nextInt();

     switch (courseSelect) {
         case 0:
             System.out.println("Stay in School!");
             System.out.println("Tuition: $" + balance);
             break;

         case 1:
             balance+= costPerCourse;
             courses += "| Film & Media | ";
             courseOptions();
             break;
         case 2:
             balance+= costPerCourse;
             courses += "| English | ";
             courseOptions();
             break;
         case 3:
             balance+= costPerCourse;
             courses += "| Public Relations | ";
             courseOptions();
             break;
         case 4:
             balance+= costPerCourse;
             courses += "| American History | ";
             courseOptions();
             break;
         case 5:
             balance+= costPerCourse;
             courses += "| Psychology | ";
             courseOptions();
             break;
         case 6:
            studentStatus();
            courseOptions();
             break;
         case 7:
             balanceCheck();
             courseOptions();
             break;
     }
     return courses;
 }

 public void balanceCheck() {

     Scanner scanner = new Scanner(System.in);

     System.out.println("Current Tuition Cost: " + balance);

     System.out.println("Pay Balance:");

     int payment = scanner.nextInt();

     balance -= payment;

     if (balance == 0) {
         System.out.println("All set! See you next semester!");
     }

     courseOptions();
 }
 public void studentStatus() {
     System.out.println("Name: " + name);
     System.out.println("ID: " + uniqueID);
     System.out.println("Courses: " + courses);
     System.out.println("Balance: " + balance);
 }
}
