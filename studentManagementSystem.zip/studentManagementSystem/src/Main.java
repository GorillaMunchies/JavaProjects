import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("How many new students will be added to the database?");

        int studentNumber = scanner.nextInt();

        studentInfo [] students = new studentInfo[studentNumber];

        for (int i = 0; i < studentNumber; i++) {
            students[i] = new studentInfo();

        }

    }
}