package org.bankingApplication;

import java.util.Scanner;


public class bank {

    private String firstName;

    private String lastName;

    private int balance = 500;

    private int newBalance;

    private int depositAmount;

    private int withdrawalAmount;

    private String deposit;

    double investAmount;



    private int previousTransaction;



    public bank() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Account Search:");
        System.out.println("Type First Name:");
        this.firstName = scanner.nextLine();
        System.out.println("Type Last Name:");
        this.lastName = scanner.nextLine();;

        setTransaction();

    }

    public int setTransaction() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome back, " + firstName + " " + lastName + ":\n1 for Deposit\n2 for Withdrawal\n3 for Interest\n4 for Balance\n5 for previous transaction\n0 to Exit ");

        int bankChoice = scanner.nextInt();

        switch (bankChoice) {
            case 0:
                System.out.println("Hope to see you again " + firstName);
            break;

            case 1:
                setDeposit();
                break;

            case 2:
                getWithdrawal();
                break;

            case 3:
                calculateInterest();
                break;

            case 4:
                checkBalance();
                break;


            case 5:
                getPreviousTransaction();
                break;
            default:

                System.out.println("Hope to see you again " + firstName);
                break;
        }

      return 0;
    }




    private int setDeposit() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Balance: " + balance);
        System.out.println("How much would you like to deposit?");
        depositAmount = scanner.nextInt();
        System.out.println("Your Deposit: $" + depositAmount);
        newBalance = balance + depositAmount;
        System.out.println("Your new balance: $" + newBalance);

        balance += depositAmount;

        previousTransaction = depositAmount;


        return setTransaction();
    }

    private int getPreviousTransaction() {

        if (previousTransaction > 0) {
            System.out.println("$" +previousTransaction + " was deposited");
        } else if (previousTransaction < 0) {
            System.out.println("$" + previousTransaction + " was withdrew");
        }   else if (previousTransaction == 0 && investAmount > 0) {
            System.out.println("You invested: $" +investAmount);
        } else if (previousTransaction == 0) {
            System.out.println("No previous transaction recorded");
        }  else {
            System.out.println("ERROR");
        }


        return setTransaction();

    }


    private int checkBalance() {

        System.out.println("Your current account balance is: $" + newBalance);

        return setTransaction();
    }



    private int getWithdrawal() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Balance: " + newBalance);
        System.out.println("How much would you like to withdrawal?");
        withdrawalAmount = scanner.nextInt();

        if (withdrawalAmount > balance) {
            System.out.println("I'm sorry, there is not enough funds in your account to make this withdrawal.");
        } else if (withdrawalAmount < balance) {
            System.out.println("Your Withdrawal Amount: $" + withdrawalAmount);
        } else {
            System.out.println("ERROR");
        }
            newBalance = balance - withdrawalAmount;
            System.out.println("Your new account balance is $ " + newBalance);
            balance -= withdrawalAmount;

            previousTransaction = withdrawalAmount *-1;


        return setTransaction();
    }

        public int calculateInterest() {
            Scanner scanner = new Scanner(System.in);

            System.out.println("How much of your balance would you like to invest into your savings account?");

            investAmount = scanner.nextInt();

            if (investAmount > newBalance) {
                System.out.println("You don't have the adequate funds to invest that amount!");
                calculateInterest();
            } else {

                double interestAmount = investAmount * 0.8;

                newBalance -= investAmount;


                System.out.println("Your interest amount is: " + interestAmount);

                previousTransaction = 0;


            } return setTransaction();
        }
        }


