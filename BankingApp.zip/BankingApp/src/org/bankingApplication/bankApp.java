package org.bankingApplication;

public class bankApp {
    public static void main(String[] args) {

        new bank();

    }
}