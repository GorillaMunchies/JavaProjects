package org.emailApplication;

import java.util.Scanner;

public class emailApp {
    public static void main(String[] args) {

        email em1 = new email("Jacob", "Rodgers");

        System.out.println(em1.showInfo());





        // Call a method asking for the department -> return the department

    }


}